import logo from './logo.svg';
import './App.css';
import 'react-toastify/dist/ReactToastify.css';

import { BrowserRouter as Router, Route ,Routes} from 'react-router-dom';
import Dashboard from './components/admin/layout/Dashboard';
import About from './components/user/general/About'
import Contact from './components/user/general/Contact';
import Home from './components/user/general/Home';

import AddCategory from './Category/AddCategory';
import EditCategory from './Category/EditCategory';
import ShowCategory from './Category/ShowCategory';
import Addproduct from './Products/AddProduct';
import Showproduct from './Products/Showproduct';
import Editproduct from './Products/Editproduct';
import Order from './Admin Orders/Order';
import CompleteOrder from './Admin Orders/CompleteOrder';
import PendingOrder from './Admin Orders/PendingOrder';
import Userlogin from './User/Userlogin';
import Signup from './User Register/SignUp';
import AdminLogin from './layouts/AdminLogin';
import AdminNote from './Admin Note/AdminNote';
import AddNote from './User Note/AddNote';
import Note from './User Note/Note';
import AllOrders from './UserOrder/Allorder'
function App(){
  return(
    <>
       <Router>         
        <Routes> 
          <Route path="/" element={<Home/>}>
            <Route path="about" element={<About/>}/>
            <Route path="contact" element={<Contact/>}/>
            <Route path="login" element={<Userlogin/>}/>
            <Route path="signup" element={<Signup/>}/>
            <Route path='myorders'element={<AllOrders/>}/>
            <Route path='adminnote' element={<AdminNote/>}/>
            {/* <Route path="data" element={<Data/>}/> */}
            <Route path="/adminLogin" element={<AdminLogin/>}/>

          </Route>
         
          
          <Route path="/admin" element={<Dashboard/>}>
            <Route path="dashboard" element={<Dashboard/>}/>
            <Route path="addcategory" element={<AddCategory/>}/>
            <Route path="showcat" element={<ShowCategory/>}/>
            <Route path="editCat/:id" element={<EditCategory/>}/>
  
          

            <Route path="addproduct" element={<Addproduct/>}/>
            <Route path="showpro" element={<Showproduct/>}/>
            <Route path="editPro/:id" element={<Editproduct/>}/>
            <Route path="orders" element={<Order/>}/>
            <Route path="completeorder" element={<CompleteOrder/>}/>
            <Route path="pendingorder" element={<PendingOrder/>}/>

            <Route path='adminnote' element={<AdminNote/>}/>
            <Route path='usernote' element={<AddNote/>}/>
            <Route path='note' element={<Note/>}/>
            
          </Route>
          
        </Routes>
      </Router>
    </>
  );
}
export default App;


