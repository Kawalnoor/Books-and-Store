import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {Component} from 'react';
import { Navigate } from 'react-router-dom';
import { baseUser,baseImageUrl } from '../../../../config/config';
import BeatLoader from "react-spinners/BeatLoader";
import qs from 'qs'
class Note extends Component{
    constructor(props){
        super(props)
        this.state={
            book:[],
            img:"book_image",
            isLoggedIn:true,
            readyToRedirect: false,
            loading:true,
            css:{
                "display": "block",
                "margin": "0 auto",
                "border-color": "blue",
                "margin-left":"550px"
            }
        }
    }
    
    componentDidMount(){
        this.setState({loading:true})
        
        let url = `${baseUser}/notes/all`
        axios.post(url,qs.stringify({status:true}))
        .then(({data})=>{
            this.setState({loading:false})

            if(data.success){
                // toast.success(data.message)
                this.setState({'book':data.data})
            }else{
                toast.warning(data.message)
            }
        })
        .catch(err=>{
            this.setState({loading:false})

            console.log("Error in ",err)
        })
    };
    state = { redirect: null };
       
    
    render(){

        
        if(!this.state.isLoggedIn){
            return <Navigate to="/Note"/>
        }
        if (this.state.navigate) {
            return <Navigate to={this.state.navigate} />
        }
        
          if(this.state.loading){
            return <>
            <BeatLoader loading={this.state.loading} css={this.state.css} size={15} />
            </>            
        }else{
            return(
                <>
                    
                    
                    <ToastContainer />
                    <div className='container'>
                    <div className="row">
                    {
                        this.state.book.map((element,index)=>(
                            <div key={index+1} className="col-md-4 
                            text-center" >
                                <table className="table table-responsive table-bordered ">
                                    <tbody>
                                    <tr>
                                        <th>Notes</th>
                                        <td>{element.title}</td>
                                    </tr>
                                    <tr>
                                        <th>Subject</th>
                                        <td>{element.subject}</td>
                                    </tr>
                                    <tr>
                                        <th>Chapter</th>
                                        <td>{element.chapter}</td>
                                    </tr>
                                    <tr>
                                        <th>Book Name</th>
                                        <td>{element.bookname}</td>
                                    </tr>
                                    <tr>
                                        <th>AddedBy</th>
                                        <td>{element?.sellerId.name}</td>
                                    </tr>
                                    <tr>
                                        <th>Notes</th>
                                        <td>
                                            <a target={`iframe${element._id}`} href={`${baseImageUrl}/${element.note}`}>
                                                Open In Frame <br/>
                                            </a>
                                            <a href={`${baseImageUrl}/${element.note}`} target="_blank">Full View</a>
                                        <iframe name={`iframe${element._id}`}>

                                        </iframe>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        ))
                    }
                    </div>
                    </div>
                </>
            )
        }
        
    }
    
}
export default Note;
