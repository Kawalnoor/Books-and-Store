import { Link } from "react-router-dom";

function AdminHeader(){
    return (
        <>
            <header id="site-header" >
                <div className="container-fluid">
                    <nav className="navbar navbar-expand-lg stroke">
                        <h1>
                            <a className="navbar-brand d-flex align-items-center" href="javascript:void(0)">
                                <img src="assets/images/logo.png" alt="" className="mr-1" />Admin Panel</a>
                        </h1>
                        <button className="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"
                            data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
                            aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
                            <span className="navbar-toggler-icon fa icon-close fa-times"></span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
                            <ul className="navbar-nav ml-lg-auto">
                                <li className="nav-item">
                                    <Link className="nav-link" to="/admin/home" >Home</Link>
                                </li>
                                <li class="nav-item dropdown">
                                    <Link className="nav-link dropdown-toggle"  data-toggle="dropdown" to="/admin/showcat">Category</Link>
                                    <ul class="dropdown-menu border-danger" >
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/addcategory">Add Category</Link>
                                        </li>
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/showcat">Show Category</Link>
                                        </li>
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/showcat">Edit Category</Link>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item dropdown">
                                    <Link className="nav-link dropdown-toggle"  data-toggle="dropdown" to="/admin/showpro">Book</Link>
                                    <ul class="dropdown-menu border-danger" >
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/addproduct">Add Book</Link>
                                        </li>
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/showpro">Show Book</Link>
                                        </li>
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/showpro">Edit Book</Link>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item dropdown">
                                    <Link className="nav-link dropdown-toggle"  data-toggle="dropdown" to="/admin/orders">Orders</Link>
                                    <ul class="dropdown-menu border-danger" >
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/orders">All Orders</Link>
                                        </li>
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/completeorder">Shipped Orders</Link>
                                        </li>
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/pendingorder">New Orders</Link>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item dropdown">
                                    <Link className="nav-link dropdown-toggle"  data-toggle="dropdown" to="/admin/notes">Notes</Link>
                                    <ul class="dropdown-menu border-danger" >
                                        <li class="nav-item">
                                            <Link className="nav-link" to="/admin/notes">All Notes</Link>
                                        </li>
                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                        <div className="cont-ser-position">
                        </div>
                    </nav>
                </div>
            </header>
            
        </>
    );
}
export default AdminHeader;