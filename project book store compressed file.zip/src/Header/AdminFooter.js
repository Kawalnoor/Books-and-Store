function AdminFooter(){
    return (
        <div>
        <footer className="w3l-footer-22 position-relative mt-5 pt-5">
            <div className="footer-sub" style={{"padding":"0px"}}>
                <div className="container">
                    <div className="text-txt">
                        <div className="row sub-columns">
                            <div className="col-lg-2 col-sm-6 sub-two-right">
                                <h6>Quick links</h6>
                                <ul>
                                    <li><a href="index.html"><span className="fa fa-angle-double-right mr-2"></span>Home</a>
                                    </li>
                                    <li><a href="about.html"><span className="fa fa-angle-double-right mr-2"></span>About</a>
                                    </li>
                                    <li><a href="courses.html"><span
                                                className="fa fa-angle-double-right mr-2"></span>Courses</a></li>
                                    <li><a href="contact.html"><span
                                                className="fa fa-angle-double-right mr-2"></span>Contact</a></li>
                                </ul>
                            </div>
                            <div className="col-lg-3 col-sm-6 sub-two-right pl-lg-5 mt-sm-0 mt-4">
                                <h6>Help & Support</h6>
                                <ul>
                                    <li><a href="#live"><span className="fa fa-angle-double-right mr-2"></span>Live
                                            Chart</a></li>
                                    <li><a href="#faq"><span className="fa fa-angle-double-right mr-2"></span>Faq</a>
                                    </li>
                                    <li><a href="#support"><span className="fa fa-angle-double-right mr-2"></span>Support</a>
                                    </li>
                                    <li><a href="#terms"><span className="fa fa-angle-double-right mr-2"></span>Terms
                                            of Services</a></li>
                                </ul>
                            </div>
                            <div className="col-lg-3 col-sm-6 sub-one-left mt-lg-0 mt-sm-5 mt-4">
                                <h6>Contact </h6>
                                <div className="column2">
                                    <div className="href1"><span className="fa fa-envelope-o" aria-hidden="true"></span><a
                                            href="mailto:info@example.com">info@example.com</a>
                                    </div>
                                    <div className="href2"><span className="fa fa-phone" aria-hidden="true"></span><a
                                            href="tel:+44-000-888-999">+44-000-888-999</a>
                                    </div>
                                    <div>
                                        <p className="contact-para"><span className="fa fa-map-marker"
                                                aria-hidden="true"></span>London, 235 Terry, 10001</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-4 col-sm-6 sub-one-left ab-right-cont pl-lg-5 mt-lg-0 mt-sm-5 mt-4">
                                <h6>About </h6>
                                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                    doloremque
                                    laudantium, totam rem aperiam, eaque ipsa quae ab.</p>
                                <div className="columns-2">
                                    <ul className="social">
                                        <li><a href="#facebook"><span className="fa fa-facebook" aria-hidden="true"></span></a>
                                        </li>
                                        <li><a href="#linkedin"><span className="fa fa-linkedin" aria-hidden="true"></span></a>
                                        </li>
                                        <li><a href="#twitter"><span className="fa fa-twitter" aria-hidden="true"></span></a>
                                        </li>
                                        <li><a href="#google"><span className="fa fa-google-plus" aria-hidden="true"></span></a>
                                        </li>
                                        <li><a href="#github"><span className="fa fa-github" aria-hidden="true"></span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="copyright-footer text-center">
                <div className="container">
                    <div className="columns">
                        <p>@2021 Studious. All rights reserved. Design by <a href="https://w3layouts.com/"
                                target="_blank">
                            W3Layouts</a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>
                </div>
    );
}
export default AdminFooter;