function About(){
    return(
        <>
                      
        <section className="video-section py-5">
            <div className="container py-md-5 py-4">
                <div className="row">
                    <div className="col-lg-6 about-right-faq align-self pr-lg-5">
                        <h3 className="title-big">Our Mission is to Provide a World‑class Education</h3>
                        <p className="mt-3">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                            ultrices in ligula. Semper at tempufddfel. </p>
                    </div>
                    <div className="col-lg-6 left-wthree-img-video text-righ pr-lg-5 mt-lg-0 mt-5">
                        <div className="position-relative text-center">
                            <img src="assets/images/about.jpg" alt="" className="img-fluid"/>
                        </div>
                    </div>
                </div>
            </div>
        </section>
                
        <section className="w3_stats pb-5" id="stats">
            <div className="container pb-md-5 pb-4 pt-4">
                <div className="w3-stats">
                    <div className="row text-center">
                        <div className="col-lg-3 col-sm-6">
                            <div className="counter">
                                <div className="timer count-title count-number" data-to="6300" data-speed="1500"></div>
                                <p className="count-text">Learners & counting</p>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-sm-0 mt-4">
                            <div className="counter">
                                <div className="timer count-title count-number" data-to="638" data-speed="1500"></div>
                                <p className="count-text">Total courses</p>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-lg-0 mt-4">
                            <div className="counter">
                                <div className="timer count-title count-number" data-to="7600" data-speed="1500"></div>
                                <p className="count-text">Successful students</p>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-lg-0 mt-4">
                            <div className="counter border-right-0">
                                <div className="timer count-title count-number" data-to="36" data-speed="1500"></div>
                                <p className="count-text">Languages</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
            
        <section className="w3l-bottom-about py-5">
            <div className="container py-md-5 py-4">
                <div className="grids-area-hny main-cont-wthree-fea row">
                    <div className="col-lg-4 col-md-6 grids-feature">
                        <div className="area-box">
                            <span className="fa fa-smile-o" aria-hidden="true"></span>
                            <h4><a href="#feature" className="title-head">Group Seminars</a></h4>
                            <p className="mb-3">Ut blandit eu leo non. Duis sed dolor amet ipsum primis
                                in faucibus orci dolor sit et amet.</p>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6 grids-feature mt-md-0 mt-4">
                        <div className="area-box">
                            <span className="fa fa-graduation-cap icon-style-2" aria-hidden="true"></span>
                            <h4><a href="#feature" className="title-head">Trending Courses</a></h4>
                            <p className="mb-3">Ut blandit eu leo non. Duis sed dolor amet ipsum primis
                                in faucibus orci dolor sit et amet.</p>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-6 grids-feature mt-lg-0 mt-4">
                        <div className="area-box">
                            <span className="fa fa-users icon-style-3" aria-hidden="true"></span>
                            <h4><a href="#feature" className="title-head">Expert Teachers</a></h4>
                            <p className="mb-3">Ut blandit eu leo non. Duis sed dolor amet ipsum primis
                                in faucibus orci dolor sit et amet.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section className="w3l-team py-sm-5 pb-sm-0 pb-5">
            <div className="container py-md-5 py-4">
                <div className="title-heading-w3 text-center mx-auto mb-5 pb-sm-4">
                    <h3 className="title-main">Who Makes the Magic Happen? <span>Know About Them</span></h3>
                </div>
                <div className="row text-center">
                    <div className="col-lg-3 col-sm-6">
                        <div className="team-block-single">
                            <div className="team-grids">
                                <a href="#team-single">
                                    <img src="assets/images/team1.jpg" className="img-fluid" alt=""/>
                                    <div className="team-info">
                                        <div className="social-icons-section">
                                            <a className="fac" href="#facebook">
                                                <span className="fa fa-facebook"></span>
                                            </a>
                                            <a className="twitter mx-2" href="#twitter">
                                                <span className="fa fa-twitter"></span>
                                            </a>
                                            <a className="google" href="#google-plus">
                                                <span className="fa fa-google-plus"></span>
                                            </a>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="team-bottom-block p-4">
                                <h5 className="member mb-1"><a href="#team">Olive Yew</a></h5>
                                <small>Teaches Design</small>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-sm-6 mt-sm-0 mt-5">
                        <div className="team-block-single">
                            <div className="team-grids">
                                <a href="#team-single">
                                    <img src="assets/images/team2.jpg" className="img-fluid" alt=""/>
                                    <div className="team-info">
                                        <div className="social-icons-section">
                                            <a className="fac" href="#facebook">
                                                <span className="fa fa-facebook"></span>
                                            </a>
                                            <a className="twitter mx-2" href="#twitter">
                                                <span className="fa fa-twitter"></span>
                                            </a>
                                            <a className="google" href="#google-plus">
                                                <span className="fa fa-google-plus"></span>
                                            </a>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="team-bottom-block p-4">
                                <h5 className="member mb-1 active"><a href="#team">Aida Joe</a></h5>
                                <small>UI/UX Designer</small>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-sm-6 mt-lg-0 mt-5">
                        <div className="team-block-single">
                            <div className="team-grids">
                                <a href="#team-single">
                                    <img src="assets/images/team3.jpg" className="img-fluid" alt=""/>
                                    <div className="team-info">
                                        <div className="social-icons-section">
                                            <a className="fac" href="#facebook">
                                                <span className="fa fa-facebook"></span>
                                            </a>
                                            <a className="twitter mx-2" href="#twitter">
                                                <span className="fa fa-twitter"></span>
                                            </a>
                                            <a className="google" href="#google-plus">
                                                <span className="fa fa-google-plus"></span>
                                            </a>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="team-bottom-block p-4">
                                <h5 className="member mb-1"><a href="#team">Teri Dac</a></h5>
                                <small>Teaches Skills</small>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-sm-6 mt-lg-0 mt-5">
                        <div className="team-block-single">
                            <div className="team-grids">
                                <a href="#team-single">
                                    <img src="assets/images/team4.jpg" className="img-fluid" alt=""/>
                                    <div className="team-info">
                                        <div className="social-icons-section">
                                            <a className="fac" href="#facebook">
                                                <span className="fa fa-facebook"></span>
                                            </a>
                                            <a className="twitter mx-2" href="#twitter">
                                                <span className="fa fa-twitter"></span>
                                            </a>
                                            <a className="google" href="#google-plus">
                                                <span className="fa fa-google-plus"></span>
                                            </a>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="team-bottom-block p-4">
                                <h5 className="member mb-1"><a href="#team">Anton Bne</a></h5>
                                <small>Web Designer</small>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-sm-6 mt-5">
                        <div className="team-block-single">
                            <div className="team-grids">
                                <a href="#team-single">
                                    <img src="assets/images/team5.jpg" className="img-fluid" alt=""/>
                                    <div className="team-info">
                                        <div className="social-icons-section">
                                            <a className="fac" href="#facebook">
                                                <span className="fa fa-facebook"></span>
                                            </a>
                                            <a className="twitter mx-2" href="#twitter">
                                                <span className="fa fa-twitter"></span>
                                            </a>
                                            <a className="google" href="#google-plus">
                                                <span className="fa fa-google-plus"></span>
                                            </a>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="team-bottom-block p-4">
                                <h5 className="member mb-1"><a href="#team">Olive Yew</a></h5>
                                <small>Teaches Design</small>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-sm-6 mt-5">
                        <div className="team-block-single">
                            <div className="team-grids">
                                <a href="#team-single">
                                    <img src="assets/images/team6.jpg" className="img-fluid" alt=""/>
                                    <div className="team-info">
                                        <div className="social-icons-section">
                                            <a className="fac" href="#facebook">
                                                <span className="fa fa-facebook"></span>
                                            </a>
                                            <a className="twitter mx-2" href="#twitter">
                                                <span className="fa fa-twitter"></span>
                                            </a>
                                            <a className="google" href="#google-plus">
                                                <span className="fa fa-google-plus"></span>
                                            </a>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="team-bottom-block p-4">
                                <h5 className="member mb-1 active"><a href="#team">Aida Joe</a></h5>
                                <small>UI/UX Designer</small>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-sm-6 mt-5">
                        <div className="team-block-single">
                            <div className="team-grids">
                                <a href="#team-single">
                                    <img src="assets/images/team7.jpg" className="img-fluid" alt=""/>
                                    <div className="team-info">
                                        <div className="social-icons-section">
                                            <a className="fac" href="#facebook">
                                                <span className="fa fa-facebook"></span>
                                            </a>
                                            <a className="twitter mx-2" href="#twitter">
                                                <span className="fa fa-twitter"></span>
                                            </a>
                                            <a className="google" href="#google-plus">
                                                <span className="fa fa-google-plus"></span>
                                            </a>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="team-bottom-block p-4">
                                <h5 className="member mb-1"><a href="#team">Teri Dac</a></h5>
                                <small>Teaches Skills</small>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-sm-6 mt-5">
                        <div className="team-block-single">
                            <div className="team-grids">
                                <a href="#team-single">
                                    <img src="assets/images/team8.jpg" className="img-fluid" alt=""/>
                                    <div className="team-info">
                                        <div className="social-icons-section">
                                            <a className="fac" href="#facebook">
                                                <span className="fa fa-facebook"></span>
                                            </a>
                                            <a className="twitter mx-2" href="#twitter">
                                                <span className="fa fa-twitter"></span>
                                            </a>
                                            <a className="google" href="#google-plus">
                                                <span className="fa fa-google-plus"></span>
                                            </a>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="team-bottom-block p-4">
                                <h5 className="member mb-1"><a href="#team">Anton Bne</a></h5>
                                <small>Web Designer</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section className="w3l-about-3 pb-5 pt-2">
            <div className="container py-md-5 py-4 mb-5">
                <div className="row align-items-center justify-content-between">
                    <div className="col-lg-6 pr-lg-5">
                        <h3 className="title-big">Join Our Mission to Democratize Education</h3>
                        <p className="mt-3">Consectetur adipiscing elit. Aliquam sit amet
                            efficitur tortor.Uspendisse efficitur orci urna.</p>
                        <ul className="list-about-2 mt-sm-4 mt-3">
                            <li className="py-1"><i className="fa fa-check-square-o mr-2" aria-hidden="true"></i>Ut enim ad minim
                                veniam</li>
                            <li className="py-2"><i className="fa fa-check-square-o mr-2" aria-hidden="true"></i>Quis nostrud
                                exercitation
                                ullamco
                                laboris</li>
                            <li className="py-1"><i className="fa fa-check-square-o mr-2" aria-hidden="true"></i>Nisi ut aliquip ex
                                ea commodo</li>
                        </ul>
                    </div>
                    <div className="col-lg-6 about-2-secs-right mt-lg-0 mt-5">
                        <img src="assets/images/about1.jpg" alt="" className="img-fluid img-responsive" />
                    </div>
                </div>
            </div>
        </section>
    </>
    );
}
export default About;