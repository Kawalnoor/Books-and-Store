import {Component} from "react";
import { Link, Outlet } from "react-router-dom";
import Footer from "./User Register/Footer";
import Header from "./User Register/Header";
function Home(){
    return(
        <>
            <Header/> 
            <Outlet/> 
            <Footer/>
        </>
    );
}
export default Home;