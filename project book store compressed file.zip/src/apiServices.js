import axios from "axios";
const BASE_URL = "http://localhost:2000/admin/"+
const token = sessionStorage.getItem("token")
const headers1={
    Accept:"application/json",
    Authorization:"token"
}

class apiServices{
    register(data){
        return axios.post(BASE_URL+"adduser",data)
    }
    getalluser(data){
        return axios.post(BASE_URL+"getalluser",data)
    }
    getsingleuser(data){
        return axios.post(BASE_URL+"getsingleuser",data)
    }
    updateuser(data){
        return axios.post(BASE_URL+"updateuser",data)
    }
     admin(data){
        return axios.post(BASE_URL+"admin",data)
    }
    login(data){
        return axios.post(BASE_URL+"login",data)
    }
    addcategory(){
        return axios.post(BASE_URL+"addcategory",{headers:headers1})
    }
    getallcategory(data){
        return axios.post(BASE_URL+"getallcategory",data,{headers:headers1})
    }
    updatecategory(data){
        return axios.post(BASE_URL+"updatecategory",data,{headers:headers1})
    }
    addproduct(data){
        return axios.post(BASE_URL+"addproduct",data,{headers:headers1})
    }
    getallproduct(data){
        return axios.post(BASE_URL+"getallproduct",data,{headers:headers1})
    }
    getsingleproduct(data){
        return axios.post(BASE_URL+"getsingleproduct",data,{headers:headers1})
    }
    updateproduct(data){
        return axios.post(BASE_URL+"updateproduct",data,{headers:headers1})
    }
}


export default new apiServices