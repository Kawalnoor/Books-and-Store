import { Link,useNavigate } from "react-router-dom"; 
import { useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import qs from "qs";
import "react-toastify/dist/ReactToastify.css";
export default function Userlogin() {
  let [email, setEmail] = useState("");
  const saveEmail = (e) => {
    setEmail(e.target.value);
  };
  let [password, setPassword] = useState("");
  const savePassword = (e) => {
    setPassword(e.target.value);
  };

  const dangerNotify =(data) =>{
    toast.error(data, {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme : "colored"
      });
  }
  
  const successNotify = () => {
    toast.success("Login Succesfully!", {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme : "colored"
      });
  };

  const Login = (e) => {
    e.preventDefault();
    console.log(email, password);
    
   
    let postData = {
      email: email,
      password: password,
    };
    axios
      .post("http://localhost:3008/api/user/login", qs.stringify(postData), {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      })
      .then((data) => {
        console.log(data);
        sessionStorage.setItem("token",data.data.token)
        sessionStorage.setItem("uid",data.data.data._id)
        setTimeout(() => {
          (data.data.success?successNotify():(dangerNotify(data.data.message)));
          if(data.data.success){
            sessionStorage.setItem("authenticate", true)
            navigate('/')
          }
          
        }, 1000);  
        
        
      });
  };
  let navigate = useNavigate();

  const test = () => {
    successNotify();
    dangerNotify();
  };

  return (
    <>          
      <section className="login py-5 border-top-1">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-5 col-md-8 align-item-center">
              <marquee direction="left to right"><h3>Login  Here To Add Your Own Notes</h3></marquee>
              <div className="border shadow">
                <h3 className="bg-gray p-4">Login Now</h3>
                <form action="">
                  <fieldset className="p-4">
                    <input
                      type="text"
                      placeholder="Enter Email"
                      className="form-control border p-3 w-100 my-2"
                      value={email}
                      onChange={saveEmail}
                    />
                    <input
                      type="password"
                      placeholder="Enter Password"
                      className="form-control border p-3 w-100 my-2"
                      value={password}
                      onChange={savePassword}
                    />

                    <button
                      type="submit"
                      className="form-control d-block py-3 px-5 bg-info text-white border-0 rounded font-weight-bold mt-3"
                      onClick={Login}
                    >
                      Log in
                    </button>
                    <a className="mt-3 d-block  text-info" href="#">
                      Forget Password?
                    </a>
                    <Link
                      className="mt-3 d-inline-block text-info"
                      to="/Signup"
                    >
                      Register Now
                    </Link>
                  </fieldset>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      <ToastContainer />
      </>
  );
}
