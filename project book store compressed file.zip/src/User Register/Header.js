import {Component, useEffect, useState} from "react";
import { Link, useNavigate } from "react-router-dom";
function Header(){
    const navigate=useNavigate()
    const [isLog,setLog] = useState(false)
    const isAuth=sessionStorage.getItem("authenticate")
    useEffect(()=>{
        const token = sessionStorage.getItem("token");
        const isAuth=sessionStorage.getItem("authenticate")
        if(token!=null && token!=undefined&& token!=""){
          setLog(true);
        }

      },[])
    const logMeout = (e)=>{
        e.preventDefault();
        window.alert("Do You Really want to Logout?")
        sessionStorage.clear();
        setLog(false);
        navigate("/login")
        // window.location.reload(true)
    }
    return(
        <>
        
            {/* <section class="w3l-top-header"> */}
                                {/* <div class="container-fluid"> */}
                                    {/* <div class="top-content-w3ls d-flex align-items-center justify-content-between"> */}
                                        {/* <div class="top-headers">
                                            <ul>
                                                <li>
                                                    <a href="#help" class="d-sm-block d-none">Have any question ?</a>
                                                </li>
                                                <li>
                                                    <i class="fa fa-phone"></i><a href="tel:6280289130">6280289130</a>
                                                </li>
                                                <li>
                                                    <i class="fa fa-envelope"></i><a href="mailto:mail@example.com">Studious@gmail.com</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="top-headers top-headers-2">
                                            <ul>
                                                <li>
                                                    <a href="#facebook"><span class="fa fa-facebook"></span></a>
                                                </li>
                                                <li>
                                                    <a href="#twitter"><span class="fa fa-twitter"></span></a>
                                                </li>
                                                <li>
                                                    <a href="#instagram"><span class="fa fa-instagram"></span></a>
                                                </li>
                                                <li class="mr-0">
                                                    <a href="#linkedin"><span class="fa fa-linkedin"></span></a>
                                                </li>
                                            </ul>
                                        </div> */}
                                    {/* </div> */}
                                {/* </div> */}
            {/* </section> */}
            <header id="site-header" class="fixed-top bg-light" style={{"background":"white"}}>
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-lg stroke">
                        <h1>
                            <div class="navbar-brand d-flex align-items-center" >
                                <img src="assets/images/logo.png" alt="" class="mr-1" />Book Store</div>
                        </h1>
                        <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"
                            data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
                            aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                            <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                            <ul class="navbar-nav ml-lg-auto ">

                                <li class="nav-item ">
                                    <Link className="nav-link" to="/" >Home</Link>
                                </li>
                                <li class="nav-item ">
                                    <Link className="nav-link" to="/About">About</Link>

                                </li>
                                <li class="nav-item">
                                    <Link className="nav-link" to="/contact">Contact Us</Link>
                                    
                                </li>
                                { isAuth ? 
                                <>
                                 <li class="nav-item">
                                    <a className="nav-link" onClick={logMeout}>Logout</a>
                                </li>
                                <li class="nav-item">
                                <Link className="nav-link" to="/addnotes">Add Notes</Link>
                            </li>
                            <li class="nav-item">
                                <Link className="nav-link" to="/myorders">My Orders</Link>
                            </li>
                            </>
                                    :
                                <li class="nav-item">
                                    <Link className="nav-link" to="/login">Login</Link>
                                </li>
                                }
                               
                                <li class="nav-item">
                                    <Link className="nav-link" to="/Bookmain">Books</Link>
                                </li>
                                <li class="nav-item">
                                    <Link className="nav-link" to="/notes">Notes</Link>
                                </li>
                                
                                

                                {/* <div class="search-right ml-lg-3">
                                    <form action="#search" method="GET" class="search-box position-relative">
                                        <div class="input-search">
                                            <input type="search" placeholder="Enter Keyword" name="search" required="required"
                                                autofocus="" class="search-popup"/>
                                        </div>
                                        <button type="submit" class="btn search-btn"><i class="fa fa-search"
                                                aria-hidden="true" ></i></button>
                                    </form>
                                </div> */}
                            </ul>
                        </div>
                        {/* <div class="cont-ser-position">
                            <nav class="navigation">
                                <div class="theme-switch-wrapper">
                                    <label class="theme-switch" for="checkbox">
                                        <input type="checkbox" id="checkbox"/>
                                        <div class="mode-container">
                                            <i class="gg-sun"></i>
                                            <i class="gg-moon"></i>
                                        </div>
                                    </label>
                                </div>
                            </nav>
                        </div> */}
                    </nav>
                </div>
            </header>
           
        </>
    );
}
export default Header;